rooms = ['101', '102', '103', '104', '105', '106', '107', '108', '109', '110'];

console.log("Rooms: ");
console.log(rooms);
