/*package SUV;

public class SUV 
{
    public static void main(String[] args)
    {
        if(s1 == "URBAN CRUISER HYRIDER")
        {
            System.out.println("You have selected URBAN CRUISER HYRIDER");
        }
        else if(s1 == "FORTUNER")
        {
            System.out.println("You have selected FORTUNER");
        }
        else if(s1 == "INNOVA CRYSTA")
        {
            System.out.println("You have selected INNOVA CRYSTA");
        }
        else if(s1 == "FORTUNER LEGENDER")
        {
            System.out.println("You have selected FORTUNER LEGENDER");
        }
    }
}
*/