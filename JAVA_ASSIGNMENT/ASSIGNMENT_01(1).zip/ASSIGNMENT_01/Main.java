import java.util.*;             // importing library
import normal.NCars;            // importing packages
import luxary.LCars;            

public class Main
{
    public static void purpose()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("\nPlease select the purpose of your visit from the list:\n[1] Car Selection\n[2] Test\t\t[Coming Soon]\n[3] Service\t\t[Coming Soon]");
        System.out.print("Disclaimer: Enter the number only!\nYour choice: ");
        int choice = sc.nextInt();
        switch(choice)
        {
            case 1:
                // Car Selection
                ();
                break;
            case 2:
                // Test 
                test();
                break;
            case 3:
                System.out.println("You have selected Service");
                break;
            default:
                System.out.println("Invalid Choice");
                break;
        }
        

    }
    static{System.out.println("Hello");}
    public static void main(String[] args)
    {
    	
        Scanner sc = new Scanner(System.in);

        // Welcome Message
        System.out.println("Welcome to LT Cars\n");                     
        //sc.nextLine();
        System.out.println("Press any key");
        // Taking Details
        String var3 = "User";
        long pno = 00L;
        while(true)
        {
            sc.nextLine();
            System.out.print("\nPlease enter your Contact Details\nName: ");          
            var3 = sc.nextLine();
            System.out.print("Contact Number: ");
            pno = sc.nextLong();

            // Displaying Details
            System.out.println("\n" +var3+ ", please recheck the details you have entered\nName: " +var3 + "\nPhone Number: " +pno);
            System.out.println("Do you want to update details: ");
            System.out.println("[1] Yes\n[2] No");
            System.out.print("Disclaimer: Enter integer only!\nYour choice: ");
            int choi = sc.nextInt();
            if(choi == 2)
            {
                break;

            }
        }
        // Taking the Purpose of Visit
        purpose();
        //sc.close();
    }
}